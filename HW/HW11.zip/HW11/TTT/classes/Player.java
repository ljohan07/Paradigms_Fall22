package TTT.classes;
import java.util.*;

public interface Player {
    public int play(Set<Integer> taken);
}